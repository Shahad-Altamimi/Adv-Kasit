<?php
/* 
------------------
Language: Arabic
------------------
*/

$lang = array();



?>

		