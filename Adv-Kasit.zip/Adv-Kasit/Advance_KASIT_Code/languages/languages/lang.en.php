<?php
/* 
------------------
Language: English
------------------
*/

$lang = array();

$lang['Title'] = 'Advance KASIT';
$lang['Title2'] = 'Advance KASIT';




$lang['Footer'] = 'Advance KASIT © 2021. All Rights Reserved.';

?>

		